#commit - 25cb847
- Added performance improvements concering formatting day in view.
- ng-class could not be replaced by ng-style to keep component styling open through css., nonetheless ng-style is much faster and I do recommend to customize the component to your needs and adjust the template anyway you need to.