$(function(){
	
	var height = document.documentElement.clientHeight;
	$('.wrap').css('height',height);
	$('.doing').css('line-height',height+'px');
	$('.do p').css('height',height/2+'px').css('line-height',height/2+'px');
    //呼叫服务页面
	if(window.location.href.indexOf('hujiaofuwu') > 0){
		setTimeout(function(){
			$('.do').show();
			$('.doing').hide();
		},3000);
		$('#stop-btn').click(function(){
			alert('stop')
		})
		var do_time = 0;
		var do_time_func = setInterval(function(){
			do_time++;
			$('#doTime').html(do_time);
		},1000)
	}
	
})