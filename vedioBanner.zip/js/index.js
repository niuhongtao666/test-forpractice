$(function(){
	
	var height = document.documentElement.clientHeight;
	$('.wrap').css('height',height);
	var do_time_func;
	//首页
	if(window.location.href.indexOf('index') > 0){
		//首页视频无线轮播
	    var vList = ['vedio/4.mp4', 'vedio/2.mp4','vedio/1.mp4','vedio/3.mp4']; // 初始化播放列表  
	    var vLen = vList.length; // 播放列表的长度  
	    var curr = 0; // 当前播放的视频  
	    var video = document.getElementById("example_video_1");  
	    video.addEventListener('ended', play);  
	    play();  
	    function play(e) {  
	        video.src = vList[curr];  
	        video.load();   
	        video.play();  
	        curr++;  
	        if(curr >= vLen){  
	            curr = 0; // 播放完了，重新播放  
	        }  
	    }
	    //工单账单模拟DMS触发
	    $('#gongdan-btn').click(function(){
	    	alert('工单账单模拟DMS触发');
	    })
	     //呼叫服务
	    $('#ask-btn').click(function(){
	    	window.location.href = 'hujiaofuwu.html';
	    })
	}
	//呼叫服务
	if(window.location.href.indexOf('hujiaofuwu') > 0){
		$('.doing').css('line-height',height+'px');
		$('.do p').css('height',height/2+'px').css('line-height',height/2+'px');
		
		//初始化客户等待时间
		var do_time = 0;
		
	    //呼叫服务页面
		setTimeout(function(){
			$('.do').show();
			$('.doing').hide();
			do_time_func = setInterval(function(){
				do_time++;
				$('#doTime').html(do_time);
			},1000)
		},3000);
		
		$('#stop-btn').click(function(){
			clearInterval(do_time_func);
			$('#helloText').html('将为您送上最真挚的服务！');
			setTimeout(function(){
				window.location.href = 'index.html';
			},3000)
			//这里将客户等待时间存入系统
		})
	}else{
		clearInterval(do_time_func)
	}
	//评价
	if(window.location.href.indexOf('pingjia') > 0){
		$('.message').css('height',height*2/3+'px');
		$('.score').css('height',height/3+'px');
		$('.info').css('height','100%');
		$('.hello').css('height','50%').css('margin-top',height/5+'px');	
		$('.hello p').css('height','50%').css('line-height','150%');
		$('.score ul').css('height','100%');
		var img_height = $('.score ul li').width();
		$('.score ul li div').css('height',img_height+'px')
							.css('margin-top','-'+img_height/2+'px')
							.css('margin-left','-'+img_height/2+'px')
							.css('border-radius',img_height/2+'px')
							.css('line-height',img_height+'px')
		//评分
		var img_score = $('.score ul li .score_img');
		console.log(img_score[1].children);
		$.each(img_score, function(index,value) {
//			console.log(value)
			console.log(1);
//			console.log($(this));
			var _this = $(this);
			_this.click(function(){
				console.log(index);
				img_score.css("opacity",0);
				var _this_index = index+1;
				if(index<=5){
					for (var i = 0; i < _this_index; i++) {
						img_score.eq(i).css('opacity',1);
					}	
				}else if(index==6||index==7){
					console.log(_this_index);
					for(var i=0;i< _this_index;i++){
						console.log(img_score[i].childNodes);
						var a=img_score[i];
						console.log(a);
						img_score[i].childNodes.css("opacity",1)
						img_score[i].childNodes.attr("src","../img/red_zhong.jpg")
					}
				}
				
				
			})
		});
	}	
})